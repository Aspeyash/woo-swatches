<?php
/**
 * Color swatch template.
 *
 * Renders a single colored square swatch as a <li> element.
 * The background-color is the hex value stored in term meta (wse_color).
 *
 * Available variables:
 *   @var string              $value        Term slug / option value e.g. 'red'.
 *   @var array<string,mixed> $swatch       {
 *       'label'        => string   Display name e.g. 'Red',
 *       'color'        => string   Hex color  e.g. '#ff0000',
 *       'is_available' => bool     Whether any variation with this term is in stock,
 *       'is_selected'  => bool     Whether this is the currently selected value,
 *   }
 *   @var string              $attribute    Attribute name e.g. 'pa_color'.
 *   @var bool                $is_selected  Shortcut from $swatch['is_selected'].
 *
 * Gap 14 — WCAG 2.2: role=radio, aria-checked, aria-disabled,
 *           tabindex, min 44px touch target (enforced in CSS)
 *
 * @package WooSwatchesElementor
 */

defined( 'ABSPATH' ) || exit;

$is_available = (bool) ( $swatch['is_available'] ?? true );
$is_selected  = (bool) ( $swatch['is_selected']  ?? false );
$label        = (string) ( $swatch['label']       ?? $value );
$color        = (string) ( $swatch['color']       ?? '#e0e0e0' );

// CSS class string
$classes = array( 'wse-swatch', 'wse-swatch-color' );
if ( $is_selected )   { $classes[] = 'selected'; }
if ( ! $is_available ) { $classes[] = 'disabled'; }
// v1.2.1 (S2) — Sale dot.
if ( ! empty( $swatch['is_on_sale'] ) ) { $classes[] = 'wse-on-sale'; }

// B5 — tabindex 0 for selected OR first-focusable (when no default selection),
// -1 for everyone else. swatches.js manages roving tabindex from there.
$is_first_focusable = isset( $is_first_focusable ) ? (bool) $is_first_focusable : false;
$tabindex           = ( $is_selected || $is_first_focusable ) ? '0' : '-1';
?>
<li class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>"
	role="radio"
	aria-label="<?php echo esc_attr(
		sprintf(
			/* translators: %s: color name */
			__( 'Color: %s', 'woo-swatches-elementor' ),
			$label
		)
	); ?>"
	aria-checked="<?php echo $is_selected ? 'true' : 'false'; ?>"
	aria-disabled="<?php echo $is_available ? 'false' : 'true'; ?>"
	tabindex="<?php echo esc_attr( $tabindex ); ?>"
	data-attribute="<?php echo esc_attr( $attribute ); ?>"
	data-value="<?php echo esc_attr( $value ); ?>"
	title="<?php echo esc_attr( $label ); ?>"
	style="background-color:<?php echo esc_attr( $color ); ?>;">

	<?php
	/**
	 * Checkmark overlay — visible when swatch is selected.
	 * Controlled by CSS:
	 *   .wse-swatch.selected .wse-checkmark { opacity: 1; }
	 *
	 * aria-hidden="true" since the parent li already has aria-checked.
	 */
	?>
	<span class="wse-checkmark" aria-hidden="true">
		<svg width="12" height="12" viewBox="0 0 12 12" fill="none"
		     xmlns="http://www.w3.org/2000/svg">
			<path d="M2 6l3 3 5-5"
			      stroke="currentColor"
			      stroke-width="1.8"
			      stroke-linecap="round"
			      stroke-linejoin="round"/>
		</svg>
	</span>

	<?php
	/**
	 * v1.5.0 (C2') — Per-swatch savings pill. Always rendered into the DOM
	 * when this term has a discount; CSS hides it by default and reveals it
	 * only when the parent .wse-attr-block carries .wse-show-savings-pill
	 * (set by the Swatches widget's "Show Savings Pill" toggle).
	 */
	$_savings_percent = (int) ( $swatch['savings_percent'] ?? 0 );
	if ( $_savings_percent > 0 ) :
	?>
	<span class="wse-swatch-savings-pill" aria-hidden="true">-<?php echo esc_html( (string) $_savings_percent ); ?>%</span>
	<?php endif; ?>

</li>
